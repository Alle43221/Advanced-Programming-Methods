package com.example.guiex1.controller;

import com.example.guiex1.HelloApplication;
import com.example.guiex1.Session;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.MessagesService;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;


public class AppStartController implements Observer<UtilizatorEntityChangeEvent> {
    UtilizatorService service;
    ReteaService service_r;
    MessagesService service_m;
    ObservableList<Utilizator> model = FXCollections.observableArrayList();

    @FXML
    Button buttonLogIn, buttonSignUp;

    public void setUtilizatorService(UtilizatorService service, ReteaService reteaService, MessagesService messagesService) {
        this.service = service;
        this.service_r = reteaService;
        this.service_m = messagesService;
        service.addObserver(this);
        initModel();
        Session session=Session.getInstance();
        session.setSessionID(null);
    }

    @FXML
    public void initialize() {
    }

    private void initModel() {
        Iterable<Utilizator> messages = service.getAll();
        List<Utilizator> users = StreamSupport.stream(messages.spliterator(), false)
                .collect(Collectors.toList());
        model.setAll(users);
    }

    @Override
    public void update(UtilizatorEntityChangeEvent utilizatorEntityChangeEvent) {
        initModel();
    }

    public void showMessageTaskEditDialog(String title, String resource) {
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(resource));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle(title);
            dialogStage.initModality(Modality.WINDOW_MODAL);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            //System.out.println(getClass().getResource("../images/icon.png").toString());
            dialogStage.getIcons().add(new Image(getClass().getResource("../images/icon.png").toString()));
//            dialogStage.getIcons().add(new Image(getClass().getResource("../images/icon_32.png").toString()));
//            dialogStage.getIcons().add(new Image(getClass().getResource("../images/icon_64.png").toString()));
//            dialogStage.getIcons().add(new Image(getClass().getResource("../images/icon_128.png").toString()));
//            dialogStage.getIcons().add(new Image(getClass().getResource("../images/icon_256.png").toString()));

            if(Objects.equals(title, "LogIn")){
                LogInController logInController = loader.getController();
                logInController.setService(service, dialogStage);
            }
            else{
                SignUpController logInController = loader.getController();
                logInController.setService(service, dialogStage);
            }

            dialogStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToUserApp() throws IOException {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("views/utilizator-view.fxml"));

        UtilizatorController userController = new UtilizatorController();

        loader.setController(userController);
        Stage stage = (Stage) buttonLogIn.getScene().getWindow();

        userController.setUtilizatorService(service, service_r, service_m, stage);
        Parent root = loader.load();


        stage.setScene(new Scene(root));
    }

    public void handleLogIn(ActionEvent actionEvent) throws IOException {
        showMessageTaskEditDialog( "LogIn", "../views/login-user.fxml");
        Session session=Session.getInstance();

        if(session.getSessionID()!=null)
        {
            goToUserApp();
        }
    }

    public void handleSignUp(ActionEvent actionEvent) throws IOException {
        showMessageTaskEditDialog("SignUp", "../views/save-user.fxml");
        Session session=Session.getInstance();
        if(session.getSessionID()!=null) {
            goToUserApp();
        }
    }
}
