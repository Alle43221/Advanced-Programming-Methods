package com.example.guiex1.controller;

import com.example.guiex1.Session;
import com.example.guiex1.domain.Message;
import com.example.guiex1.domain.ReplyMessage;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.MessagesService;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.MessageEntityChangeEvent;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class ChatController implements Observer<MessageEntityChangeEvent>{
    ObservableList<ReplyMessage> modelMessages = FXCollections.observableArrayList();
    private UtilizatorService service;
    private ReteaService service_r;
    private MessagesService service_m;
    Stage dialogStage;
    private Utilizator from;
    private Utilizator to;
    private Long replyingTo;

    @FXML
    Button buttonSend;
    @FXML
    Button buttonReply;
    @FXML
    TextField textFieldMessage;
    @FXML
    Label labelReplyingTo;
    @FXML
    ListView<ReplyMessage> listViewMessages;
    @FXML
    Button buttonRemoveReply;

    public void setService(ReteaService service_r, UtilizatorService service, MessagesService service_m, Stage stage, Utilizator from, Utilizator to) {
        this.service = service;
        this.dialogStage=stage;
        this.service_r=service_r;
        this.service_m = service_m;
        this.from = from;
        this.to = to;
        this.service_m.addObserver(this);
        labelReplyingTo.setVisible(false);
        replyingTo=0L;
        initModel();
    }

    @FXML
    public void initialize() {
        listViewMessages.setCellFactory(lv -> new ListCell<ReplyMessage>() {
            @Override
            protected void updateItem(ReplyMessage message, boolean empty) {
                super.updateItem(message, empty);
                if (empty || message == null) {
                    setText(null);
                    setGraphic(null);
                } else {

                    HBox cellLayout = new HBox(10);

                    if(Objects.equals(message.getFrom().getId(), Session.getInstance().getSessionID())){
                        Image trashcanImage = new Image(getClass().getResourceAsStream("../images/trashcan.png"));
                        ImageView trashcanIcon = new ImageView(trashcanImage);
                        trashcanIcon.setFitWidth(15); // Resize to your desired width
                        trashcanIcon.setFitHeight(15);
                        Button deleteButton = new Button();
                        deleteButton.setId("messageDeleteButton");
                        deleteButton.setGraphic(trashcanIcon);
                        deleteButton.setOnAction(e -> {
                            service_m.deleteMessage(message);
//                            System.out.println("Message deleted: " + message.getMessage());
                        });
                        cellLayout.getChildren().add(deleteButton);
                    }

                    Label timeLabel = new Label(String.format("%02d:%02d %02d/%02d/%02d", message.getData().getHour(), message.getData().getMinute(),
                            message.getData().getDayOfMonth(), message.getData().getMonthValue(), message.getData().getYear()));
                    timeLabel.setId("messageTimeLabel");
                    Label messageLabel = new Label(message.getMessage());
                    HBox.setHgrow(messageLabel, Priority.ALWAYS);

                    cellLayout.getChildren().addAll(timeLabel, messageLabel);



                    if(message.getFrom().getId()==from.getId()){
                        cellLayout.setAlignment(Pos.CENTER_RIGHT);

                    }
                    else {
                        cellLayout.setAlignment(Pos.CENTER_LEFT);

                    }

                    if(message.getReply()!=0){
                        Label reply;
                        Optional<ReplyMessage> replymsg=service_m.findOne(message.getReply());
                        if(replymsg.isPresent()){
                            if(replymsg.get().getMessage().length()>30){
                                reply= new Label("Replying to: " + replymsg.get().getMessage().substring(0, 30)+"...");
                            }
                            else{
                                reply= new Label("Replying to: " + replymsg.get().getMessage());
                            }
                        }
                        else{
                            reply= new Label("Replying to: " +"This message was deleted.");
                        }

                        VBox VcellLayout = new VBox(20);

                        VcellLayout.getChildren().addAll(reply, cellLayout);
                        VcellLayout.setAlignment(cellLayout.getAlignment());
                        setGraphic(VcellLayout);
                    }
                    else{
                        setGraphic(cellLayout);
                    }
                    Image replyImage = new Image(getClass().getResourceAsStream("../images/reply.png"));
                    ImageView replyIcon = new ImageView(replyImage);
                    replyIcon.setFitWidth(10);
                    replyIcon.setFitHeight(10);
                    Button replyButton = new Button();
                    replyButton.setId("replyButton");
                    replyButton.setGraphic(replyIcon);
                    replyButton.setOnAction(e -> handleReply(message));
                    cellLayout.getChildren().add(replyButton);
                }
            }
        });
        listViewMessages.setItems(modelMessages);

    }


    @Override
    public void update(MessageEntityChangeEvent utilizatorEntityChangeEvent) {
        if(Session.getInstance().getSessionID()!=null){
            initModel();
        }
    }

    private void initModel() {
        List<ReplyMessage> messages=service_m.getChat(from, to).stream().toList();
        modelMessages.setAll(messages);
        listViewMessages.scrollTo(modelMessages.size() - 1);
    }

    public void handleSend(ActionEvent actionEvent) {
        String message=textFieldMessage.getText();
        if(message.isEmpty()){}
        else
        {
            Optional<ReplyMessage> result=service_m.addMessage(new ReplyMessage(message, from, to, replyingTo));
            if(!result.isPresent()){
                textFieldMessage.setText("");
                labelReplyingTo.setText("");
                labelReplyingTo.setVisible(false);
            }
        }
    }

    public void handleReply(ReplyMessage msg) {
            replyingTo=msg.getId();
            if(msg.getMessage().length()>30)
                labelReplyingTo.setText("Replying to: " + msg.getMessage().substring(0, 30)+"...");
            else{
                labelReplyingTo.setText("Replying to: " + msg.getMessage());
            }
            labelReplyingTo.setVisible(true);
    }

    public void handleRemoveReply(ActionEvent actionEvent) {
        replyingTo=0L;
        labelReplyingTo.setText("");
        labelReplyingTo.setVisible(false);
    }
}
