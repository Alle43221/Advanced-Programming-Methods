package com.example.guiex1.controller;

import com.example.guiex1.Session;
import com.example.guiex1.domain.FriendRequest;
import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.ChangeEventType;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observable;
import com.example.guiex1.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.awt.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class FriendRequestsController implements Observer<UtilizatorEntityChangeEvent> {
    ObservableList<Utilizator> modelReceived = FXCollections.observableArrayList();
    ObservableList<Utilizator> modelSent = FXCollections.observableArrayList();
    @FXML
    TableView<Utilizator> tableSent;
    @FXML
    TableView<Utilizator> tableReceived;
    @FXML
    Button buttonAccept;
    @FXML
    Button buttonDelete;
    @FXML
    Tab tabRequestsReceived;
    @FXML
    Tab tabRequestsSent;
    @FXML
    TabPane tabPane;
    @FXML
    TableColumn<Utilizator,String> tableColumnFirstNameReceived;
    @FXML
    TableColumn<Utilizator,String> tableColumnLastNameReceived;
    @FXML
    TableColumn<Utilizator,String> tableColumnIdReceived;
    @FXML
    TableColumn<Utilizator,String> tableColumnFirstNameSent;
    @FXML
    TableColumn<Utilizator,String> tableColumnLastNameSent;
    @FXML
    TableColumn<Utilizator,String> tableColumnIdSent;


    private UtilizatorService service;
    private ReteaService service_r;
    Stage dialogStage;

    public void setService(ReteaService service_r, UtilizatorService service, Stage stage) {
        this.service = service;
        this.dialogStage=stage;
        this.service_r=service_r;

        service.addObserver(this);
        service_r.addObserver(this);
        initModelFriends();
    }

    @FXML
    public void initialize() {
        tableColumnFirstNameReceived.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tableColumnLastNameReceived.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tableColumnIdReceived.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableReceived.setItems(modelReceived);

        tableColumnFirstNameSent.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tableColumnLastNameSent.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tableColumnIdSent.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableSent.setItems(modelSent);

    }

    private void initModelFriends() {
        Iterable<Utilizator> friendsReceived, friendsSent;
        Session s=Session.getInstance();
        if(s.getSessionID()==null){}
        else {
            Optional<Utilizator> utilizator = service.findOne(s.getSessionID());
            friendsReceived = service_r.getMyPendingRequests(utilizator.get());
            friendsSent = service_r.getUsersWithPendingRequests(utilizator.get());

            List<Utilizator> users1 = StreamSupport.stream(friendsSent.spliterator(), false)
                    .collect(Collectors.toList());
            List<Utilizator> users2 = StreamSupport.stream(friendsReceived.spliterator(), false)
                    .collect(Collectors.toList());
            modelReceived.setAll(users2);
            modelSent.setAll(users1);
        }
    }

    @Override
    public void update(UtilizatorEntityChangeEvent utilizatorEntityChangeEvent) {
        initModelFriends();
    }

    @FXML
    public void handleAccept(ActionEvent actionEvent) {
        Tab tab=tabPane.getSelectionModel().getSelectedItem();
        if(tab!=null) {
            Session session=Session.getInstance();
            Utilizator user=tableReceived.getSelectionModel().getSelectedItem();
            if(user!=null) {
                Utilizator  user1=service.findOne(session.getSessionID()).get();
                service_r.addPrietenie(user, user1);
                Optional<FriendRequest> result=service_r.deleteFriendRequest(user, user1);
                if(result.isPresent()){
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"","Request accepted.");
                }
            }
            else{
                MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No request selected.");
            }
        }
    }

    @FXML
    public void handleDelete(ActionEvent actionEvent) {
        Tab tab=tabPane.getSelectionModel().getSelectedItem();
        if(tab!=null) {
            Session session=Session.getInstance();
            Utilizator user;
            if(tab==tabRequestsReceived) {
                 user = tableReceived.getSelectionModel().getSelectedItem();
            }
            else {
                user = tableSent.getSelectionModel().getSelectedItem();
            }
            if(user!=null) {
                Utilizator  user1=service.findOne(session.getSessionID()).get();
                service_r.deleteFriendRequest(user1,user);
            }
            else{
                MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No request selected.");
            }
        }
    }

    @FXML
    public void handleRequestTabSelection(Event event) {
        if(tabRequestsSent.isSelected()){
            buttonAccept.setDisable(true);
        }
        else{
            buttonAccept.setDisable(false);
        }
    }
}
