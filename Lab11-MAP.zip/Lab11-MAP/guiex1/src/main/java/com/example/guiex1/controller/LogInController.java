package com.example.guiex1.controller;

import com.example.guiex1.Session;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.ValidationException;
import com.example.guiex1.services.UtilizatorService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.Optional;

public class LogInController {
    @FXML
    public PasswordField passwordField;
    @FXML
    private TextField textFieldEmail;


    private UtilizatorService service;
    Stage dialogStage;

    @FXML
    private void initialize() {
    }

    public void setService(UtilizatorService service,  Stage stage) {
        this.service = service;
        this.dialogStage=stage;
    }

    @FXML
    public void handleLogIn(){
        String emailText=textFieldEmail.getText();
        String passText= passwordField.getText();

        Optional<Utilizator> utilizator1=service.findByCredentials(emailText, passText);

        if(utilizator1.isPresent()){
            logInUser(utilizator1.get());
        }
        else{
            MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Invalid User","Email and password don't match");
        }
    }

    private void logInUser(Utilizator m)
    {
            Session session=Session.getInstance();
            Long id=session.getSessionID();
            if (id==null)
            {
                session.setSessionID(m.getId());
            }
        dialogStage.close();
    }

    @FXML
    public void handleCancel(){
        dialogStage.close();
    }
}
