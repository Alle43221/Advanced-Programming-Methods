package com.example.guiex1.controller;


import com.example.guiex1.Session;
import com.example.guiex1.domain.Message;
import com.example.guiex1.domain.ReplyMessage;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.MessageEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;
import java.util.Objects;
import java.util.stream.StreamSupport;


public class ProfileEditController implements Observer<MessageEntityChangeEvent>{

    @FXML
    public ImageView imageView;
    @FXML
    public TextField textFieldFirstname;
    @FXML
    public TextField textFieldLastname;
    @FXML
    public TextArea textAreaDesc;
    @FXML
    public PasswordField textFieldPass;
    @FXML
    public PasswordField textFieldPassConfirm;


    Stage dialogStage;
    Utilizator utilizatorApp;
    ReteaService service_r;
    UtilizatorService service;


    public void setService( ReteaService service, Stage stage, Utilizator user, UtilizatorService utilizatorservice) {
        this.service_r = service;
        this.dialogStage=stage;
        this.utilizatorApp=user;
        this.service=utilizatorservice;
        initModel();
    }

    @FXML
    public void initialize() {
    }


    @Override
    public void update(MessageEntityChangeEvent utilizatorEntityChangeEvent) {
        initModel();
    }

    private void initModel() {

        textFieldFirstname.setText(utilizatorApp.getFirstName());
        textFieldLastname.setText(utilizatorApp.getLastName());
        textAreaDesc.setText(utilizatorApp.getDescription());

        if(utilizatorApp.getProfileImage()==null){
            imageView.setImage(new Image(getClass().getResource("../images/user_image.png").toString()));
        }
        else{
            imageView.setImage(utilizatorApp.getProfileImage());
        }
    }

    @FXML
    public void handlePassReset() {
        Utilizator u = utilizatorApp;
        u.setPassword(textFieldPass.getText());
        if(Objects.equals(textFieldPass.getText(), "")){
            MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "Password must be not null");
            return;
        }
        if(textFieldPassConfirm.getText().equals(textFieldPass.getText())) {
            if(service.updatePassword(u)==null){
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "", "Password reset successful");
                textFieldPass.setText("");
                textFieldPassConfirm.setText("");
                utilizatorApp=service.findOne(utilizatorApp.getId()).get();
            }
            else{
                MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "Invalid password");
            }
        }
        else{
            MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "Passwords must match");
        }
    }

    @FXML
    public void handleClose(){
        dialogStage.close();
    }

    @FXML
    public void handleSave() {
        Utilizator u= utilizatorApp;
        u.setFirstName(textFieldFirstname.getText());
        u.setLastName(textFieldLastname.getText());
        u.setDescription(textAreaDesc.getText());
        u.setProfileImage(imageView.getImage());
        if(service.updateUtilizator(u)==null){
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "", "Updated information successful");
            textFieldPass.setText("");
            textFieldPassConfirm.setText("");
            utilizatorApp=service.findOne(utilizatorApp.getId()).get();
        }
        else{
            MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "Invalid input");
        }
    }

    @FXML
    public void handleUpload() {
        FileChooser fileChooser = new FileChooser();

        FileChooser.ExtensionFilter extFilterPNG
                = new FileChooser.ExtensionFilter("PNG files (*.PNG)", "*.PNG");
        FileChooser.ExtensionFilter extFilterpng
                = new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
        fileChooser.getExtensionFilters()
                .addAll(extFilterPNG, extFilterpng);
        //Show open file dialog
        File file = fileChooser.showOpenDialog(null);

        if(file!=null){
            try {
                BufferedImage bufferedImage = ImageIO.read(file);
                WritableImage writableImage = new WritableImage(bufferedImage.getWidth(), bufferedImage.getHeight());
                PixelWriter pixelWriter = writableImage.getPixelWriter();

                for (int y = 0; y < bufferedImage.getHeight(); y++) {
                    for (int x = 0; x < bufferedImage.getWidth(); x++) {
                        int argb = bufferedImage.getRGB(x, y);
                        Color fxColor = Color.rgb(
                                (argb >> 16) & 0xFF, // Red
                                (argb >> 8) & 0xFF,  // Green
                                argb & 0xFF,         // Blue
                                ((argb >> 24) & 0xFF) / 255.0 // Alpha
                        );
                        pixelWriter.setColor(x, y, fxColor);
                    }
                }
                imageView.setImage(writableImage);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void handleDeleteAccount() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Account Delete Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to delete your account? All your chats will be lost.");
        if (alert.showAndWait().filter(response -> response.getText().equals("OK")).isPresent()) {
            service_r.deleteUtilizator(utilizatorApp.getId());
            dialogStage.close();
        }
    }
}
