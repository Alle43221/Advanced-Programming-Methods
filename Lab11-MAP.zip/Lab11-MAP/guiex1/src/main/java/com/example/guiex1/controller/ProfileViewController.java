package com.example.guiex1.controller;


import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.MessageEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.FormatStyle;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;


public class ProfileViewController implements Observer<MessageEntityChangeEvent>{
    @FXML
    public Label labelName;
    @FXML
    public Label labelFriendsMutual;
    @FXML
    public Label labelDesc;
    @FXML
    public Label labelFriends;
    @FXML
    public Label labelFriendsSince;
    @FXML
    public ImageView imageView;
    private UtilizatorService service;
    private ReteaService service_r;
    Stage dialogStage;
    Utilizator utilizatorApp;
    Utilizator ownerOfProfile;


    public void setService(ReteaService service_r, UtilizatorService service, Stage stage, Utilizator user, Utilizator owner) {
        this.service = service;
        this.dialogStage=stage;
        this.service_r=service_r;
        this.ownerOfProfile=owner;
        this.utilizatorApp=user;
        initModel();
    }

    @FXML
    public void initialize() {
    }


    @Override
    public void update(MessageEntityChangeEvent utilizatorEntityChangeEvent) {
        initModel();
    }

    private void initModel() {
        labelName.setText(ownerOfProfile.getFirstName()+ " " + ownerOfProfile.getLastName()
                + " (id: " + ownerOfProfile.getId() + ")");

        if(ownerOfProfile.getDescription()==null || ownerOfProfile.getDescription().equals("")){
            labelDesc.setText("No bio yet...");
        }
        else{
            labelDesc.setText(ownerOfProfile.getDescription());
        }
        List<Utilizator> friendsOfUser=StreamSupport.stream(service_r.getFriends(utilizatorApp).spliterator(), false).toList();
        List<Utilizator> friendsOfOwner=StreamSupport.stream(service_r.getFriends(ownerOfProfile).spliterator(), false).toList();
        List<Utilizator> mutualFriendsOfOwner= StreamSupport.stream(friendsOfOwner.spliterator(), false).filter(
                u->{
                    return friendsOfUser.contains(service.findOne(u.getId()).get());
                }
        ).toList();

        if(ownerOfProfile.getProfileImage()==null){
            imageView.setImage(new Image(getClass().getResource("../images/user_image.png").toString()));
        }
        else{
            imageView.setImage(ownerOfProfile.getProfileImage());
        }

        labelFriends.setText("Number of friends: " + friendsOfOwner.size());
        labelFriendsMutual.setText("Mutual friends: " + mutualFriendsOfOwner.size());
        Optional<Prietenie> result=service_r.findPrietenie(utilizatorApp, ownerOfProfile);
        if(result.isPresent()){
            labelFriendsSince.setText("Friends since: " +
                    result.get().getCreatedAt().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)));
        }
        else{
            labelFriendsSince.setText("");
        }

    }

    @FXML
    public void handleClose(){
        dialogStage.close();
    }
}
