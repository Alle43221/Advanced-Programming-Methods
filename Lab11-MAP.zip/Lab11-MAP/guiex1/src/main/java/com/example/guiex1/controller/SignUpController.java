package com.example.guiex1.controller;

import com.example.guiex1.Session;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.ValidationException;
import com.example.guiex1.services.UtilizatorService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController {

    @FXML
    public TextField textFieldFirstName;
    @FXML
    public TextField textFieldLastName;
    @FXML
    private TextField textFieldEmail;
    @FXML
    private PasswordField textFieldPassword;
    @FXML
    private PasswordField textFieldConfirmPassword;

    private UtilizatorService service;
    Stage dialogStage;

    @FXML
    public void initialize() {

    }

    public void setService(UtilizatorService service, Stage stage) {
        this.service = service;
        this.dialogStage=stage;
    }

    public void saveUser(ActionEvent actionEvent) {
        String firstName=textFieldFirstName.getText();
        String lastName=textFieldLastName.getText();
        String email=textFieldEmail.getText();
        String password=textFieldPassword.getText();
        String confirmPassword=textFieldConfirmPassword.getText();

        if(firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Empty fields","Please fill the required fields.");
            return;
        }

        if(confirmPassword.equals(password)) {
            Utilizator m=new Utilizator(firstName, lastName, email, password);
            try {
                Utilizator r= this.service.addUtilizator(m);
                if (r==null){
                    r=this.service.findByCredentials(email, password).get();
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Account created","You are now logged in your new account.");
                    Session.getInstance().setSessionID(r.getId());
                    dialogStage.close();
                }
                else{
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Account exists","An account already exists for this email.");
                }
            } catch (ValidationException e) {
                MessageAlert.showErrorMessage(null,e.getMessage());
            }
        }
        else{
            MessageAlert.showMessage(null, Alert.AlertType.WARNING,"","Passwords do not match");
        }
    }

    @FXML
    public void handleCancel(){
        dialogStage.close();
    }
}
