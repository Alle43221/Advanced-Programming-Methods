package com.example.guiex1.domain;

import java.time.LocalDateTime;
import java.util.Objects;

public class Message extends Entity<Long>{
    private String message;
    private Utilizator from;
    private Utilizator to;
    private LocalDateTime data;
    public Message(String message, Utilizator from, Utilizator to, LocalDateTime data) {
        this.message = message;
        this.from = from;
        this.to = to;
        this.data = data;
    }

    public Message(String message, Utilizator from, Utilizator to) {
        this.message = message;
        this.from = from;
        this.to = to;
        this.data = LocalDateTime.now();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Utilizator getFrom() {
        return from;
    }

    public void setFrom(Utilizator from) {
        this.from = from;
    }

    public Utilizator getTo() {
        return to;
    }

    public void setTo(Utilizator to) {
        this.to = to;
    }

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Message message1 = (Message) o;
        return getId().equals(message1.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
