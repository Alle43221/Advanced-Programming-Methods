package com.example.guiex1.domain;

import java.time.LocalDateTime;
import java.util.Objects;

public class ReplyMessage extends Message{
    private Long reply;
    public ReplyMessage(String message, Utilizator from, Utilizator to, LocalDateTime data,Long reply) {
        super(message, from, to, data);
        this.reply = reply;
    }

    public ReplyMessage(String message, Utilizator from, Utilizator to,Long reply) {
        super(message, from, to);
        this.reply = reply;
    }

    public Long getReply() {
        return reply;
    }

    public void setReply(Long reply) {
        this.reply = reply;
    }

}
