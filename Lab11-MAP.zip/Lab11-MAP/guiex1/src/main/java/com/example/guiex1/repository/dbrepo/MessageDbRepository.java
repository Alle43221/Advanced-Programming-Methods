package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.ReplyMessage;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.Validator;
import com.example.guiex1.repository.Repository;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class MessageDbRepository implements Repository<Long, ReplyMessage> {
    private String url;
    private String username;
    private String password;
    private Validator<ReplyMessage> validator;
    private final Repository<Long, Utilizator> utilizatorRepository;


    public MessageDbRepository(String url, String username, String password, Validator<ReplyMessage> validator, Repository<Long, Utilizator> utilizatorRepository) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
        this.utilizatorRepository = utilizatorRepository;
    }

    /**
     * @param id - long, the id of a user to found
     * @return Optional<User> - the user with the given id
     *                        -Optional.empty() otherwise
     */
    @Override
    public Optional<ReplyMessage> findOne(Long id) {
        ReplyMessage message;
        try(Connection connection = DriverManager.getConnection(url, username, password);
            ResultSet resultSet = connection.createStatement().executeQuery(String.format("select * from messages U where U.id = '%d'", id))) {
            if(resultSet.next()){
                message = createMessageFromResultSet(resultSet);
                return Optional.ofNullable(message);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }


    private ReplyMessage createMessageFromResultSet(ResultSet resultSet) {
        try {
           Long id_from  = resultSet.getLong("from");
           Long id_to  = resultSet.getLong("to");
           String message = resultSet.getString("message");
           LocalDateTime dateFrom = resultSet.getTimestamp("date").toLocalDateTime();
           Long replyTo = resultSet.getLong("replyTo");

            Long idd = resultSet.getLong("id");
            ReplyMessage r= new ReplyMessage(message,
                    utilizatorRepository.findOne(id_from).get(), utilizatorRepository.findOne(id_to).get(), dateFrom, replyTo);
            r.setId(idd);
            return r;
        } catch (SQLException e) {
            return null;
        }
    }

    @Override
    public Iterable<ReplyMessage> findAll() {
        List<ReplyMessage> messages = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from messages ORDER BY \"date\"");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                ReplyMessage message = createMessageFromResultSet(resultSet);
                messages.add(message);
            }
            return messages;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }

    @Override
    public Optional<ReplyMessage> save(ReplyMessage entity) {
        String sql = "INSERT INTO messages (\"from\", \"to\", \"message\", \"replyto\") VALUES (?, ?, ?, ?)";

        validator.validate(entity);
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setLong(1, entity.getFrom().getId());
            ps.setLong(2, entity.getTo().getId());
            ps.setString(3, entity.getMessage());
            ps.setLong(4, entity.getReply());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return Optional.ofNullable(entity);
        }
        return Optional.empty();
    }

    @Override
    public Optional<ReplyMessage> delete(Long id) {
        String sql = "delete from messages where id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
             Optional<ReplyMessage> user = findOne(id);
            if(!user.isEmpty()) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            return user;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<ReplyMessage> update(ReplyMessage entity) {
        if(entity == null)
            throw new IllegalArgumentException("entity must be not null!");
        validator.validate(entity);
        String sql = "update messages set \"from\" = ?, \"to\" = ?, \"message\"=?, \"date\"=?, \"replyto\"=? where itod = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, entity.getFrom().getId());
            ps.setLong(2, entity.getTo().getId());
            ps.setString(3, entity.getMessage());
            ps.setObject(4, entity.getData());
            ps.setLong(5, entity.getReply());
            ps.setLong(6, entity.getId());
            if( ps.executeUpdate() > 0 )
                return Optional.empty();
            return Optional.of(entity);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

}
