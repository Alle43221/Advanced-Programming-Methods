package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.Validator;
import com.example.guiex1.repository.Repository;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.*;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

public class UtilizatorDbRepository implements Repository<Long, Utilizator> {
    private String url;
    private String username;
    private String password;
    private Validator<Utilizator> validator;

    public UtilizatorDbRepository(String url, String username, String password, Validator<Utilizator> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    /**
     * @param id - long, the id of a user to found
     * @return Optional<User> - the user with the given id
     *                        -Optional.empty() otherwise
     */
    @Override
    public Optional<Utilizator> findOne(Long id) {
        Utilizator user;
        try(Connection connection = DriverManager.getConnection(url, username, password);
            ResultSet resultSet = connection.createStatement().executeQuery(String.format("select * from users U where U.id = '%d'", id))) {
            if(resultSet.next()){
                user = createUserFromResultSet(resultSet);
                return Optional.ofNullable(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }


    private Utilizator createUserFromResultSet(ResultSet resultSet) {
        try {
            String firstName = resultSet.getString("first_name");
            String lastName = resultSet.getString("last_name");
            String email = resultSet.getString("email");
            String password = resultSet.getString("password");
            String description = resultSet.getString("dscription");

            InputStream imageStream = resultSet.getBinaryStream("profile_picture");
            Image image = null;
            if (imageStream != null) {
                image = new Image(imageStream);
            }

            Long idd = resultSet.getLong("id");
            Utilizator user = new Utilizator(firstName, lastName, email, password, description);
            user.setProfileImage(image);
            user.setId(idd);
            return user;
        } catch (SQLException e) {
            return null;
        }
    }

    @Override
    public Iterable<Utilizator> findAll() {
        Set<Utilizator> users = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from users");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Utilizator utilizator = createUserFromResultSet(resultSet);
                users.add(utilizator);
            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    @Override
    public Optional<Utilizator> save(Utilizator entity) {
        String sql = "insert into users (first_name, last_name, email, password, dscription) values (?, ?, ?, ?, ?)";
        validator.validate(entity);
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, entity.getFirstName());
            ps.setString(2, entity.getLastName());
            ps.setString(3, entity.getEmail());
            ps.setString(4, entity.getPassword());
            ps.setString(5, entity.getDescription());
            ps.executeUpdate();
        } catch (SQLException e) {
            //e.printStackTrace();
            return Optional.ofNullable(entity);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Utilizator> delete(Long id) {
        String sql = "delete from users where id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
            Optional<Utilizator> user = findOne(id);
            if(!user.isEmpty()) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            return user;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<Utilizator> update(Utilizator user) {
        if(user == null)
            throw new IllegalArgumentException("entity must be not null!");
        validator.validate(user);
        String sql = "update users set first_name = ?, last_name = ?, email=?, password=?, dscription=?, profile_picture=? where id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3,user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getDescription());
            Image profileImage=user.getProfileImage();
            if(profileImage!=null){
                WritableImage writableImage = new WritableImage((int) profileImage.getWidth(), (int) profileImage.getHeight());
                writableImage.getPixelWriter().setPixels(0, 0, (int) profileImage.getWidth(), (int) profileImage.getHeight(),
                        profileImage.getPixelReader(), 0, 0);

                // Create a ByteArrayOutputStream to hold the image data
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                // Write the image data to the byte array as PNG (or another format)
                writeImageToByteArray(writableImage, byteArrayOutputStream);

                // Get the byte array of the image
                byte[] imageBytes = byteArrayOutputStream.toByteArray();

                // Convert the byte array into an InputStream
                ByteArrayInputStream imageInputStream = new ByteArrayInputStream(imageBytes);

                ps.setBinaryStream(6, imageInputStream, (int) imageBytes.length);
            }
            else{
                ps.setNull(6, Types.BINARY);
            }
            ps.setLong(7, user.getId());
            if( ps.executeUpdate() > 0 )
                return Optional.empty();
            return Optional.ofNullable(user);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    private void writeImageToByteArray(WritableImage writableImage, ByteArrayOutputStream byteArrayOutputStream) throws IOException {
        // Convert WritableImage to BufferedImage (needed for image writing)
        BufferedImage bufferedImage = new BufferedImage(
                (int) writableImage.getWidth(),
                (int) writableImage.getHeight(),
                BufferedImage.TYPE_3BYTE_BGR // Choose RGB type
        );

        PixelReader pixelReader = writableImage.getPixelReader();

        // Manually copy the pixel data from WritableImage to BufferedImage
        for (int y = 0; y < writableImage.getHeight(); y++) {
            for (int x = 0; x < writableImage.getWidth(); x++) {
                Color color = pixelReader.getColor(x, y);
                int argb = (int) (color.getOpacity() * 255) << 24 | (int) (color.getRed() * 255) << 16 |
                        (int) (color.getGreen() * 255) << 8 | (int) (color.getBlue() * 255);
                bufferedImage.setRGB(x, y, argb);
            }
        }

        // Write the BufferedImage to the ByteArrayOutputStream in PNG format (you can use JPEG too)
        ImageIO.write(bufferedImage, "PNG", byteArrayOutputStream);
    }

}
