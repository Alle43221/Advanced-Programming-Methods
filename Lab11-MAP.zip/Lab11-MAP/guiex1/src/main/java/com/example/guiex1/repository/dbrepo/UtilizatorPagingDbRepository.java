package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.Validator;
import com.example.guiex1.utils.paging.Page;
import com.example.guiex1.utils.paging.Pageable;
import javafx.scene.image.Image;

import java.io.InputStream;
import java.sql.*;
import java.util.*;

public class UtilizatorPagingDbRepository implements UtilizatorPagingRepository {
    private String url;
    private String username;
    private String password;
    private Validator<com.example.guiex1.domain.Utilizator> validator;

    public UtilizatorPagingDbRepository(String url, String username, String password, Validator<com.example.guiex1.domain.Utilizator> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    /**
     * @param id - long, the id of a user to found
     * @return Optional<User> - the user with the given id
     *                        -Optional.empty() otherwise
     */
    @Override
    public Optional<com.example.guiex1.domain.Utilizator> findOne(java.lang.Long id) {
        com.example.guiex1.domain.Utilizator user;
        try(Connection connection = DriverManager.getConnection(url, username, password);
            ResultSet resultSet = connection.createStatement().executeQuery(String.format("select * from users U where U.id = '%d'", id))) {
            if(resultSet.next()){
                user = createUserFromResultSet(resultSet);
                return Optional.ofNullable(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    private com.example.guiex1.domain.Utilizator createUserFromResultSet(ResultSet resultSet) {
        try {
            String firstName = resultSet.getString("first_name");
            String lastName = resultSet.getString("last_name");
            String email = resultSet.getString("email");
            String password = resultSet.getString("password");
            String description = resultSet.getString("dscription");

            InputStream imageStream = resultSet.getBinaryStream("profile_picture");
            Image image = null;
            if (imageStream != null) {
                image = new Image(imageStream);
            }

            Long idd = resultSet.getLong("id");
            Utilizator user = new Utilizator(firstName, lastName, email, password, description);
            user.setProfileImage(image);
            user.setId(idd);
            return user;
        } catch (SQLException e) {
            return null;
        }
    }

    @Override
    public Iterable<com.example.guiex1.domain.Utilizator> findAll() {
        Set<com.example.guiex1.domain.Utilizator> users = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from users");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                com.example.guiex1.domain.Utilizator utilizator = createUserFromResultSet(resultSet);
                users.add(utilizator);
            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    @Override
    public Optional<com.example.guiex1.domain.Utilizator> save(com.example.guiex1.domain.Utilizator entity) {
        String sql = "insert into users (first_name, last_name, email, password, dscription) values (?, ?, ?, ?, ?)";
        validator.validate(entity);
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, entity.getFirstName());
            ps.setString(2, entity.getLastName());
            ps.setString(3, entity.getEmail());

            ps.setString(4, entity.getPassword());
            ps.setString(5, entity.getDescription());
            ps.executeUpdate();
        } catch (SQLException e) {
            //e.printStackTrace();
            return Optional.ofNullable(entity);
        }
        return Optional.empty();
    }

    @Override
    public Optional<com.example.guiex1.domain.Utilizator> delete(java.lang.Long id) {
        String sql = "delete from users where id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
            Optional<com.example.guiex1.domain.Utilizator> user = findOne(id);
            if(!user.isEmpty()) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            return user;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<com.example.guiex1.domain.Utilizator> update(com.example.guiex1.domain.Utilizator user) {
        if(user == null)
            throw new IllegalArgumentException("entity must be not null!");
        validator.validate(user);
        String sql = "update users set first_name = ?, last_name = ?, email=?, password=?, dscription=? where id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3,user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getDescription());
            ps.setLong(6, user.getId());
            if( ps.executeUpdate() > 0 )
                return Optional.empty();
            return Optional.ofNullable(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Page<Utilizator> findAllOnPage(Pageable pageable, Long id) {
        return findAllOnPageFilter(pageable, id, null);
    }

    private int sizeWithFilter(Connection connection, String query, List<Long> l, String filter) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(query);) {
            Array sqlArray = connection.createArrayOf("INTEGER", l.toArray());
            statement.setObject(1, sqlArray);
            if(filter!=null){
                String filterWildcard = "%" + filter + "%";
                statement.setString(2, filterWildcard);
                statement.setString(3, filterWildcard);
            }
            ResultSet resultSet = statement.executeQuery();
            int i=0;
            while (resultSet.next()) {
                i++;
            }
            return i;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Page<Utilizator> findAllOnPageFilter(Pageable pageable, Long aLong, String filter) {

        List<Utilizator> friends = new ArrayList<>();
        List<Long> ids = new ArrayList<>();

        if(aLong==null){
            String query = "Select id from users";
            try (Connection connection = DriverManager.getConnection(url, username, password);
                 PreparedStatement statement = connection.prepareStatement(query);) {
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    Long id1 = resultSet.getLong("id");
                    ids.add(id1);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        else{
            String query = "Select * from friendships where id1= ? OR id2= ?";
            try (Connection connection = DriverManager.getConnection(url, username, password);
                 PreparedStatement statement = connection.prepareStatement(query);) {

                statement.setLong(  1, aLong);
                statement.setLong( 2, aLong);
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    Long id1 = resultSet.getLong("id1");
                    Long id2 = resultSet.getLong("id2");
                    if(id1.equals(aLong)){
                        ids.add(id2);
                    }else  ids.add(id1);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        String query2 = "Select * from users where id = ANY(?)";

        if (filter != null) {
            query2 += " AND (first_name ILIKE ? OR last_name ILIKE ?)";
        }
        String query3=query2;

        query2 += " LIMIT ? OFFSET ? ";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(query2);) {

            Array sqlArray = connection.createArrayOf("INTEGER", ids.toArray());
            statement.setObject(1, sqlArray);
            if (filter != null) {
                String filterWildcard = "%" + filter + "%";
                statement.setString(2, filterWildcard);
                statement.setString(3, filterWildcard);
                statement.setInt(4, pageable.getPageSize());
                statement.setInt(5, pageable.getPageNumber() * pageable.getPageSize());
            }
            else{
                statement.setInt(2, pageable.getPageSize());
                statement.setInt(3, pageable.getPageNumber() * pageable.getPageSize());
            }

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Utilizator user=createUserFromResultSet(resultSet);
                friends.add(user);
            }
            return new Page<>(friends, sizeWithFilter(connection, query3, ids, filter));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
