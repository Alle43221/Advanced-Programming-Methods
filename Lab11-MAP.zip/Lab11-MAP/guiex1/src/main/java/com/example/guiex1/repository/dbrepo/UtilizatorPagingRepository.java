package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.repository.PagingRepository;
import com.example.guiex1.utils.paging.Page;
import com.example.guiex1.utils.paging.Pageable;

public interface UtilizatorPagingRepository extends PagingRepository<Long, Utilizator> {
    Page<Utilizator> findAllOnPageFilter(Pageable pageable, Long id, String filter);
    Page<Utilizator> findAllOnPage(Pageable pageable, Long id);
}
