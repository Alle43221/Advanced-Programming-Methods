package com.example.guiex1.services;

import com.example.guiex1.domain.ReplyMessage;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.repository.Repository;
import com.example.guiex1.utils.events.ChangeEventType;
import com.example.guiex1.utils.events.MessageEntityChangeEvent;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observable;
import com.example.guiex1.utils.observer.Observer;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MessagesService implements Observable<MessageEntityChangeEvent> {
    private List<Observer<MessageEntityChangeEvent>> observers=new ArrayList<>();
    private Repository<Long, ReplyMessage> repo;

    public MessagesService(Repository<Long, ReplyMessage> repo) {
        this.repo = repo;
    }

    @Override
    public void addObserver(Observer<MessageEntityChangeEvent> e) {
        observers.add(e);
    }



    @Override
    public void removeObserver(Observer<MessageEntityChangeEvent> e) {
        //observers.remove(e);
    }

    @Override
    public void notifyObservers(MessageEntityChangeEvent t) {

        observers.stream().forEach(x->x.update(t));
    }

    public List<ReplyMessage> getChat(Utilizator from, Utilizator to){
        Iterable<ReplyMessage> result= repo.findAll();
        if(result==null){
            return new ArrayList<>();
        }
       return StreamSupport.stream(result.spliterator(), false)
               .filter(t-> (Objects.equals(from.getId(), t.getFrom().getId()) && to.getId()==t.getTo().getId())
               || (from.getId()==t.getTo().getId() && to.getId()==t.getFrom().getId())).collect(Collectors.toList());
    }

    public Optional<ReplyMessage> addMessage(ReplyMessage replyMessage) {
        Optional<ReplyMessage> result=repo.save(replyMessage);
        notifyObservers(new MessageEntityChangeEvent(ChangeEventType.ADD,replyMessage));
        return result;
    }

    public Optional<ReplyMessage> findOne(Long replyingTo) {
        return repo.findOne(replyingTo);
    }

    public Optional<ReplyMessage> deleteMessage(ReplyMessage message) {
        Optional<ReplyMessage> result=repo.delete(message.getId());
        notifyObservers(new MessageEntityChangeEvent(ChangeEventType.DELETE,message));
        return  result;
    }
}

