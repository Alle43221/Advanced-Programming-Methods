package com.example.guiex1.services;

import com.example.guiex1.Session;
import com.example.guiex1.domain.*;
import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.repository.Repository;
import com.example.guiex1.repository.dbrepo.FriendRequestDbRepository;
import com.example.guiex1.utils.events.ChangeEventType;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observable;
import com.example.guiex1.utils.observer.Observer;
import com.example.guiex1.utils.paging.Page;
import com.example.guiex1.utils.paging.Pageable;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;


/**
 * The ServiceCommunities class provides functionality for analyzing user communities
 * within a social Retea. It calculates the number of connected communities and
 * identifies the most social community based on friendships.
 */
public class ReteaService implements Observable<UtilizatorEntityChangeEvent> {
    private Retea retea;
    private HashMap<Long, List<Long>> adjList;
    private List<Observer<UtilizatorEntityChangeEvent>> observers=new ArrayList<>();
    private final FriendRequestDbRepository friendRequestDbRepository;
    private final Repository<Long, ReplyMessage> messageDbRepository;

    @Override
    public void addObserver(Observer<UtilizatorEntityChangeEvent> e) {
        observers.add(e);
    }

    @Override
    public void removeObserver(Observer<UtilizatorEntityChangeEvent> e) {
        //observers.remove(e);
    }

    @Override
    public void notifyObservers(UtilizatorEntityChangeEvent t) {

        observers.stream().forEach(x->x.update(t));
    }
    
    /**
     * Constructs a ServiceCommunities object with the specified Retea.
     *
     * @param retea The Retea containing users and friendships.
     */
    public ReteaService(Retea retea, FriendRequestDbRepository friendRequestDbRepository, Repository<Long, ReplyMessage> messageRepository
                        ) {
        this.retea = retea;
        this.friendRequestDbRepository = friendRequestDbRepository;
        this.messageDbRepository=messageRepository;
    }

    /**
     * Constructs the adjacency list from the friendships in the Retea.
     * Each user is mapped to a list of their friends.
     */
    private void setAdjList() {
        adjList = new HashMap<>();
        Retea.getUtilizatorRepo().findAll().forEach(
                user -> {
                    List<Long> friends = new ArrayList<>();
                    Iterable<Prietenie> friendships = Retea.getPrietenieRepo().findAll();
                    if (friendships.iterator().hasNext()) {
                        Retea.getPrietenieRepo().findAll().forEach(
                                friendship -> {
                                    if (friendship.getUserId1().equals(user.getId()))
                                        friends.add(friendship.getUserId2());
                                    if (friendship.getUserId2().equals(user.getId()))
                                        friends.add(friendship.getUserId1());
                                }
                        );
                        //System.out.println(friends);
                        adjList.put(user.getId(), friends);
                    }
                }
        );
    }

    public Iterable<Utilizator> getFriends(Utilizator user) {
        setAdjList();
        List<Utilizator> friends = new ArrayList<>();
        Repository<Long, Utilizator> repo = Retea.getUtilizatorRepo();
        if(adjList.containsKey(user.getId())) {
            adjList.get(user.getId()).forEach(
                    friend -> {
                        Optional<Utilizator> aux=repo.findOne(friend);
                        aux.ifPresent(friends::add);
                    }
            );
        }
        return friends;
    }

    public Optional<Prietenie> deletePrietenie(Utilizator user, Utilizator friend) {
        Repository<Tuple<Long, Long>, Prietenie> repo = Retea.getPrietenieRepo();
        Prietenie p=new Prietenie(user.getId(), friend.getId());
        Optional<Prietenie> result = repo.delete(p.getId());
        if(result.isPresent())
        {
            notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.DELETE, friend));
        }
        return result;
    }

    public Optional<Prietenie> addPrietenie(Utilizator user, Utilizator friend) {
        Repository<Tuple<Long, Long>, Prietenie> repo = Retea.getPrietenieRepo();
        Prietenie p=new Prietenie(user.getId(), friend.getId());
        Optional<Prietenie> result = repo.save(p);
        if(result.isPresent())
        {
            notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.DELETE, friend));
        }
        return result;
    }

    public Optional<FriendRequest> addFriendRequest(Utilizator user, Utilizator friend) {

        Optional<FriendRequest> result = friendRequestDbRepository.save(new FriendRequest(user.getId(), friend.getId()));
        notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.DELETE, friend));
        return  result;
    }

    public Iterable<Utilizator> getUsersWithPendingRequests(Utilizator user){
        Iterable<FriendRequest> friends;
        friends=StreamSupport.stream(friendRequestDbRepository.findAll().
                        spliterator(), false).filter(u-> (u.getsource()==user.getId()))
                .collect(Collectors.toList());
        List<Utilizator> users=new ArrayList<>();
        StreamSupport.stream(friends.
                spliterator(), false).forEach(u->{
                    users.add(retea.getUtilizatorRepo().findOne(u.getdestination()).get());
        });
        return users;
    }

    public Iterable<Utilizator> getMyPendingRequests(Utilizator user){
        Iterable<FriendRequest> friends;
        friends=StreamSupport.stream(friendRequestDbRepository.findAll().
                        spliterator(), false).filter(u-> (u.getdestination()==user.getId()))
                .collect(Collectors.toList());
        List<Utilizator> users=new ArrayList<>();
        //System.out.println(friends);
        if(!friends.iterator().hasNext()){
            return new ArrayList<>();
        }
        StreamSupport.stream(friends.spliterator(), false).forEach(u -> {
            retea.getUtilizatorRepo().findOne(u.getsource()).ifPresent(users::add);
        });
        return users;
    }

    public  Optional<FriendRequest> deleteFriendRequest(Utilizator user, Utilizator friend) {
        Optional<FriendRequest> result = friendRequestDbRepository.delete(new Tuple<>(user.getId(), friend.getId()));
        notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.DELETE, friend));
        return result;
    }

    public Page<Utilizator> findAllOnPage(Pageable pageable,  Utilizator user, String filter) {
        if(user==null){
            return retea.getUtilizatorRepo().findAllOnPageFilter(pageable,  null, filter);
        }
        return retea.getUtilizatorRepo().findAllOnPageFilter(pageable, (Long) user.getId(), filter);
    }

    public Optional<Prietenie> findPrietenie(Utilizator user1, Utilizator user2) {
        if(user1.getId()>user2.getId()){
            return retea.getPrietenieRepo().findOne(new Tuple<>(user2.getId(), user1.getId()));
        }
        return retea.getPrietenieRepo().findOne(new Tuple<>(user1.getId(), user2.getId()));
    }

    public void deleteUtilizator(Long id){
        Session.getInstance().setSessionID(null);
        try{
                Iterable<FriendRequest> p= this.friendRequestDbRepository.findAll();
                for(FriendRequest f1: p) {
                    if(Objects.equals(f1.getsource(), id)){
                        this.friendRequestDbRepository.delete(f1.getId());
                    }
                    if(Objects.equals(f1.getdestination(), id)){
                        this.friendRequestDbRepository.delete(f1.getId());
                    }
                }
                Iterable<ReplyMessage> m= this.messageDbRepository.findAll();
                for(Message m1: m) {
                    if(Objects.equals(m1.getFrom().getId(), id)){
                        this.messageDbRepository.delete(m1.getId());
                    }
                    if(Objects.equals(m1.getTo().getId(), id)){
                        this.messageDbRepository.delete(m1.getId());
                    }
                }

                Iterable<Prietenie> f= Retea.getPrietenieRepo().findAll();
                for(Prietenie f1: f) {
                    if(Objects.equals(f1.getUserId1(), id)){
                        Retea.getPrietenieRepo().delete(f1.getId());
                    }

                    if(Objects.equals(f1.getUserId2(), id)){
                        Retea.getPrietenieRepo().delete(f1.getId());
                    }
                }
                Optional<Utilizator> user= Retea.getUtilizatorRepo().delete(id);

                notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.DELETE, new Utilizator()));
        }
        catch(Exception e){
            e.printStackTrace();
        }

    }
}