package com.example.guiex1.controller;

import com.example.guiex1.HelloApplication;
import com.example.guiex1.Session;
import com.example.guiex1.domain.FriendRequest;
import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.ChangeEventType;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class UtilizatorController implements Observer<UtilizatorEntityChangeEvent> {

    UtilizatorService service;
    ReteaService service_r;
    ObservableList<Utilizator> model = FXCollections.observableArrayList();
    List<Utilizator> data = new ArrayList<>();
    Stage stageRequests=null;

    @FXML
    TableView<Utilizator> tableView;
    @FXML
    TableColumn<Utilizator,String> tableColumnFirstName;
    @FXML
    TableColumn<Utilizator,String> tableColumnLastName;
    @FXML
    TableColumn<Utilizator,String> tableColumnId;
    @FXML
    Button buttonLogOut;
    @FXML
    Label welcomeMessage;
    @FXML
    TextField textFieldSearch;
    @FXML
    Button buttonDelete;
    @FXML
    Button buttonSendRequest;
    @FXML
    Button buttonShowFriends;
    @FXML
    Button buttonSearch;
    @FXML
    Button buttonViewRequests;


    public void setUtilizatorService(UtilizatorService service, ReteaService t) {
        this.service = service;
        this.service_r=t;
        service.addObserver(this);
        service_r.addObserver(this);
        initModelFriends();
    }

    @FXML
    public void initialize() {
        tableColumnFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tableColumnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tableColumnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableView.setItems(model);
    }

    private void initModelFriends() {
            Session s=Session.getInstance();
            Optional<Utilizator> utilizator = service.findOne(s.getSessionID());
            Iterable<Utilizator> friends;

            if(utilizator.isPresent()) {
                friends = service_r.getFriends(utilizator.get());
                welcomeMessage.setText("Hello, "  + utilizator.get().getFirstName()+"!");
            }
            else{
                friends = service.getAll();
                welcomeMessage.setText("Hey, you should login!");
            }
            List<Utilizator> users = StreamSupport.stream(friends.spliterator(), false)
                    .collect(Collectors.toList());
            model.setAll(users);
             buttonShowFriends.setDisable(true);
             buttonSendRequest.setDisable(true);
             textFieldSearch.setText("");
    }

    private void initModelSearch() {
        List<Utilizator> users = new ArrayList<>(data);
        model.setAll(users);
        buttonShowFriends.setDisable(false);
        buttonSendRequest.setDisable(false);
    }

    @Override
    public void update(UtilizatorEntityChangeEvent utilizatorEntityChangeEvent) {
        if(utilizatorEntityChangeEvent.getType()== ChangeEventType.FILTER){
            initModelSearch();
        }
        else{
            initModelFriends();
        }
    }

    public void handleAddFriend(ActionEvent actionEvent) {
        Utilizator user = tableView.getSelectionModel().getSelectedItem();
        if (user != null) {
            Session s = Session.getInstance();
            Optional<Utilizator> curent = service.findOne(s.getSessionID());

            for (Utilizator friend : service_r.getFriends(curent.get())) {
                if (friend.getId() == user.getId()) {
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "Selection Error", "User is already friend.");
                    return;
                }
            }

            for (Utilizator friend : service_r.getUsersWithPendingRequests(curent.get())) {
                if (friend.getId() == user.getId()) {
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "Selection Error", "User has pending request.");
                    return;
                }
            }

            try {
                Optional<FriendRequest> result=service_r.addFriendRequest(curent.get(), user);
                if(result.isPresent()){
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "This user has already sent you a friend request.");
                }
                else{
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "", "Friend request sent.");
                }
            } catch (Exception e) {
                if(e.getMessage()=="Duplicate ID"){
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "You should be your own best friend! :)");
                }
                else{
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", e.getMessage());
                }
        }
        }
        else MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No user selected.");
    }

    public void handleSearchFriend(){
        String nume=textFieldSearch.getText();
        if(!nume.isEmpty()){
            Session s = Session.getInstance();
            Optional<Utilizator> curent = service.findOne(s.getSessionID());
            data = StreamSupport.stream(service_r.filterByName(curent.get(), nume).spliterator(), false).toList();
            service.notifyObservers(new UtilizatorEntityChangeEvent(ChangeEventType.FILTER, curent.get()));
        }
        else{
            MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","Please provide a name");
        }
    }

    public void handleDeleteFriend(ActionEvent actionEvent) {
        Utilizator user = tableView.getSelectionModel().getSelectedItem();
        if (user != null) {
            Session s = Session.getInstance();
            Optional<Utilizator> curent = service.findOne(s.getSessionID());
            try{
                Optional<Prietenie> deleted = service_r.deletePrietenie(curent.get(), user);
                if(deleted.isPresent()) {
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"","Friend deleted.");
                }
            }
            catch (Exception e){
                MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "User is not a friend.");
            }

        }
        else MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No friend selected.");
    }

    public void handleLogOut(ActionEvent actionEvent) throws IOException {
        Session session=Session.getInstance();
        session.setSessionID(null);
        if(stageRequests!=null){
            stageRequests.close();
            stageRequests=null;
        }
    FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("views/app-start.fxml"));
    Parent root = loader.load();
    Stage stage = (Stage) buttonLogOut.getScene().getWindow();
    stage.setScene(new Scene(root));

    AppStartController userController = loader.getController();
        userController.setUtilizatorService(service, service_r);
    }

    public void handleReset(ActionEvent actionEvent) {
        initModelFriends();
    }

    public void handleViewRequests(ActionEvent actionEvent) throws IOException {
        if(stageRequests==null || !stageRequests.isShowing()){
            FXMLLoader loader = new FXMLLoader();
        loader.setLocation(HelloApplication.class.getResource("views/friend-requests.fxml"));
        AnchorPane root = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Friend Requests");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        Scene scene = new Scene(root);
        dialogStage.setScene(scene);

        dialogStage.show();
        stageRequests=dialogStage;

        FriendRequestsController editUserController = loader.getController();
        editUserController.setService(service_r, service, dialogStage);
        }

    }
}
