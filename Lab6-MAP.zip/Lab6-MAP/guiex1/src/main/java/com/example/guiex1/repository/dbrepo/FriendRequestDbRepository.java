package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.FriendRequest;
import com.example.guiex1.domain.Tuple;
import com.example.guiex1.domain.validators.Validator;
import com.example.guiex1.repository.RepoException;
import com.example.guiex1.repository.Repository;

import java.sql.*;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class FriendRequestDbRepository  implements Repository<Tuple<Long, Long>, FriendRequest> {
    private final String url;
    private final String username;
    private final String password;
    private final Validator<FriendRequest> validator;

    public FriendRequestDbRepository(String url, String username, String password, Validator<FriendRequest> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    @Override
    public Optional<FriendRequest> findOne(Tuple<Long, Long> a) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from friendrequests WHERE source = ? and requests = ?")
        ) {

            statement.setLong(1, a.getLeft());
            statement.setLong(2, a.getRight());

            ResultSet resultSet=statement.executeQuery();
            if (!resultSet.next())
            {
                return Optional.empty();
            }

            resultSet.getLong("source");
            resultSet.getLong("destination");
            FriendRequest FriendRequest = new FriendRequest(a.getLeft(), a.getRight());
            return Optional.of(FriendRequest);
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            throw new RepoException("Could not fetch FriendRequest");
        }
    }


    /**
     * Retrieves all FriendRequests from the database.
     *
     * @return an Iterable collection of all FriendRequests in the database
     */
    @Override
    public Iterable<FriendRequest> findAll() {
        Set<FriendRequest> FriendRequests = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from friendrequests");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id1 = resultSet.getLong("source");
                Long id2 = resultSet.getLong("destination");

                FriendRequest FriendRequest = new FriendRequest(id1, id2);
                FriendRequests.add(FriendRequest);
            }
            return FriendRequests;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
//            throw new RepoException("Could not fetch FriendRequests");
        }
        return null;
    }

    /**
     * Saves a FriendRequest entity to the database.
     *
     * @param entity the FriendRequest entity to save
     * @return an Optional containing the FriendRequest if the save was unsuccessful, or an empty Optional if successful
     */
    @Override
    public Optional<FriendRequest> save(FriendRequest entity) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO friendrequests (source, destination) VALUES (?, ?)")
        ) {
            validator.validate(entity); //throws ValidationError
            Iterable<FriendRequest> fr=findAll();
            for(FriendRequest i: fr){
                if(i.getdestination()==entity.getsource()&&i.getsource()==entity.getdestination())
                    return Optional.of(entity);
            }
            statement.setLong(1, entity.getsource());
            statement.setLong(2, entity.getdestination());
            int rez = statement.executeUpdate();
            if (rez > 0)
                return Optional.empty();
            else
                return Optional.of(entity);
        } catch (SQLException e) {
            throw new RepoException("Could not save FriendRequest");
        }
    }

    /**
     * Deletes a FriendRequest by the IDs of the two users involved.
     *
     * @param a a Tuple containing the IDs of the two users in the FriendRequest
     * @return an Optional containing the deleted FriendRequest if successful, or an empty Optional if not found
     */
    @Override
    public Optional<FriendRequest> delete(Tuple<Long, Long> a) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement result = connection.prepareStatement("SELECT * FROM friendrequests WHERE source = ? and destination=?");
             PreparedStatement statement = connection.prepareStatement("DELETE FROM friendrequests WHERE source = ? and destination=?")
        ) {
            result.setLong(1, a.getLeft());
            result.setLong(2, a.getRight());
            statement.setLong(1, a.getLeft());
            statement.setLong(2, a.getRight());
            ResultSet resultSet = result.executeQuery();
            resultSet.next();
            resultSet.getLong("source");
            resultSet.getLong("destination");

            FriendRequest FriendRequest = new FriendRequest(a.getLeft(), a.getRight());
            statement.executeUpdate();
            return Optional.of(FriendRequest);

        } catch (SQLException e) {
//            System.out.println(e.getMessage());
            throw new RepoException("Could not delete FriendRequest - non existent FriendRequest");
        }
    }

    /**
     * Updates a FriendRequest entity in the database.
     *
     * @param entity the FriendRequest entity with updated information
     * @return an Optional containing the updated FriendRequest if successful, or an empty Optional if not found
     */
    @Override
    public Optional<FriendRequest> update(FriendRequest entity) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("Select * FROM friendrequests WHERE source=? AND destination=?")
        ) {
            statement.setLong(1, entity.getsource());
            statement.setLong(2, entity.getdestination());
            int rez=statement.executeUpdate();
            if(rez<1){
                return Optional.empty();
            }
            return Optional.of(entity);

        } catch (SQLException e) {
//            System.out.println(e.getMessage());
            throw new RepoException("Could not update FriendRequest - non existent FriendRequest");
        }
    }
}
