package com.example.guiex1.domain;

import com.example.guiex1.repository.Repository;

/**
 * The Retea class represents a social Retea that manages Utilizators and their Prietenies.
 * It provides access to Utilizator and Prietenie repositories, which store and manage the data
 * related to Utilizators and their connections.
 */
public class Retea {
    private static Repository<Long, Utilizator> UtilizatorRepo;
    private static Repository<Tuple<Long, Long>, Prietenie> PrietenieRepo;

    /**
     * Returns the repository for Utilizator entities.
     *
     * @return The Utilizator repository.
     */
    public static Repository<Long, Utilizator> getUtilizatorRepo() {
        return UtilizatorRepo;
    }

    /**
     * Sets the repository for Utilizator entities.
     *
     * @param UtilizatorRepo The repository to be set for managing Utilizators.
     */
    public void setUtilizatorRepo(Repository<Long, Utilizator> UtilizatorRepo) {
        this.UtilizatorRepo = UtilizatorRepo;
    }

    /**
     * Returns the repository for Prietenie entities.
     *
     * @return The Prietenie repository.
     */
    public static Repository<Tuple<Long, Long>, Prietenie> getPrietenieRepo() {
        return PrietenieRepo;
    }

    /**
     * Sets the repository for Prietenie entities.
     *
     * @param PrietenieRepo The repository to be set for managing Prietenies.
     */
    public void setPrietenieRepo(Repository<Tuple<Long, Long>, Prietenie> PrietenieRepo) {
        this.PrietenieRepo = PrietenieRepo;
    }

    /**
     * Constructs a Retea object with the specified Utilizator and Prietenie repositories.
     *
     * @param UtilizatorRepo        The repository for managing Utilizator entities.
     * @param PrietenieRepo  The repository for managing Prietenie entities.
     */
    public Retea(Repository<Long, Utilizator> UtilizatorRepo, Repository<Tuple<Long, Long>, Prietenie> PrietenieRepo) {
        this.UtilizatorRepo = UtilizatorRepo;
        this.PrietenieRepo = PrietenieRepo;
    }
}