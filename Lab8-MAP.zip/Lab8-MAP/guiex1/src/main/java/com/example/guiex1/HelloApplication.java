package com.example.guiex1;

import com.example.guiex1.controller.AppStartController;
import com.example.guiex1.domain.*;
import com.example.guiex1.domain.validators.FriendRequestValidator;
import com.example.guiex1.domain.validators.MessageValidator;
import com.example.guiex1.domain.validators.PrietenieValidator;
import com.example.guiex1.domain.validators.UtilizatorValidator;
import com.example.guiex1.repository.Repository;
import com.example.guiex1.repository.dbrepo.*;
import com.example.guiex1.services.MessagesService;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;

import java.io.IOException;

public class HelloApplication extends Application {

    ReteaService service_r;
    UtilizatorService service;
    MessagesService service_ms;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        System.out.println("Reading data from file");
        String username="postgres";
        String pasword="dabaeuisale";
        String url="jdbc:postgresql://localhost:5432/socialnetwork";
        Repository<Long, Utilizator> utilizatorRepository =
                new UtilizatorDbRepository(url,username, pasword,  new UtilizatorValidator());

        Repository<Tuple<Long, Long>, Prietenie> prietenieRepository =
                new PrietenieDbRepository(url,username, pasword, PrietenieValidator.getInstance());

        Repository<Long, ReplyMessage> messageRepository =
                new MessageDbRepository(url,username, pasword, new MessageValidator(), utilizatorRepository);

        UtilizatorPagingRepository utilizatorPagingRepository= new UtilizatorPagingDbRepository(url, username, pasword, new UtilizatorValidator());
        Retea r=new Retea(utilizatorPagingRepository,prietenieRepository);
        FriendRequestDbRepository fr=new FriendRequestDbRepository(url,username, pasword, FriendRequestValidator.getInstance());

        service =new UtilizatorService(utilizatorRepository);
        service_r=new ReteaService(r, fr);
        service_ms=new MessagesService(messageRepository);
        initView(primaryStage);
        primaryStage.setTitle("MINTY");
        primaryStage.setWidth(800);
        primaryStage.getIcons().add(new Image(getClass().getResource("images/icon.png").toString()));
        primaryStage.getIcons().add(new Image(getClass().getResource("images/icon_32.png").toString()));
        primaryStage.getIcons().add(new Image(getClass().getResource("images/icon_64.png").toString()));
        primaryStage.getIcons().add(new Image(getClass().getResource("images/icon_128.png").toString()));
        primaryStage.getIcons().add(new Image(getClass().getResource("images/icon_256.png").toString()));
        primaryStage.show();

    }

    private void initView(Stage primaryStage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("views/app-start.fxml"));
        AnchorPane userLayout = fxmlLoader.load();
        primaryStage.setScene(new Scene(userLayout));
        AppStartController controller = fxmlLoader.getController();
        controller.setUtilizatorService(service, service_r, service_ms);
    }
}
