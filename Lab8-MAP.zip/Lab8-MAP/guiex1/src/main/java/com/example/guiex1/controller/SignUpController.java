package com.example.guiex1.controller;

import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.domain.validators.ValidationException;
import com.example.guiex1.services.UtilizatorService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class SignUpController {

    private UtilizatorService service;
    Stage dialogStage;

    @FXML
    public void initialize() {

    }

    public void setService(UtilizatorService service, Stage stage) {
        this.service = service;
        this.dialogStage=stage;
    }

//    private void saveUser(Utilizator m)
//    {
//        try {
//            Utilizator r= this.service.updateUtilizator(m);
//            if (r==null){
//                dialogStage.close();
//                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Account created","You are now logged in your new account");
//                Stage stage = (Stage) textFieldEmail.getScene().getWindow();
//                stage.getProperties().clear();
//                stage.getProperties().put("userid", m.getId());
//            }
//        } catch (ValidationException e) {
//            MessageAlert.showErrorMessage(null,e.getMessage());
//        }
//    }
}
