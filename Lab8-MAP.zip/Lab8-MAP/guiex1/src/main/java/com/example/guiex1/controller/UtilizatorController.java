package com.example.guiex1.controller;

import com.example.guiex1.HelloApplication;
import com.example.guiex1.Session;
import com.example.guiex1.domain.FriendRequest;
import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.MessagesService;
import com.example.guiex1.services.ReteaService;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.ChangeEventType;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import com.example.guiex1.utils.paging.Page;
import com.example.guiex1.utils.paging.Pageable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;

public class UtilizatorController implements Observer<UtilizatorEntityChangeEvent> {

    MessagesService messagesService;
    UtilizatorService service;
    ReteaService service_r;
    ObservableList<Utilizator> model = FXCollections.observableArrayList();
    List<Utilizator> data = new ArrayList<>();
    Stage stageRequests=null;
    Iterable<Utilizator> friends;
    String filter="";
    private int currentPage=0;
    private int currentPageSize=2;

    @FXML
    TableView<Utilizator> tableView;
    @FXML
    TableColumn<Utilizator,String> tableColumnFirstName;
    @FXML
    TableColumn<Utilizator,String> tableColumnLastName;
    @FXML
    TableColumn<Utilizator,String> tableColumnId;
    @FXML
    TableColumn<Utilizator,Void> tableColumnButtons;
    @FXML
    Button buttonLogOut;
    @FXML
    Label welcomeMessage=new Label("");
    @FXML
    TextField textFieldSearch=new TextField();
    @FXML
    Button buttonSendRequest=new Button("Send Request");
    @FXML
    Button buttonShowFriends=new Button("Show Friends");
    @FXML
    Label pageLabel=new Label("");

    @FXML
    Button previousButton=new Button("<");
    @FXML
    Button nextButton=new Button(">");


    public void setUtilizatorService(UtilizatorService service, ReteaService t, MessagesService ms) {
        currentPage=0;
        this.service = service;
        this.service_r=t;
        this.messagesService=ms;
        this.service.addObserver(this);
        service_r.addObserver(this);
        friends=service_r.getFriends(service.findOne(Session.getInstance().getSessionID()).get());
        initModelFriends();
    }

    private void deployNotification() {
        Session s = Session.getInstance();
        Optional<Utilizator> curent = service.findOne(s.getSessionID());
        Iterable<Utilizator> result=service_r.getMyPendingRequests(curent.get());
        if(result.iterator().hasNext()) {
            long size = StreamSupport.stream(result.spliterator(), false).count();
            if(size==1){
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,
                        "Pending Friend Requests",
                        "Yay! You have one possible friend!");
            }
            else if (size>1){
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,
                        "Pending Friend Requests",
                        "Yay! You have " + size + " possible friends!");
            }
        }
    }

    @FXML
    public void initialize() {
        deployNotification();
        textFieldSearch.textProperty().addListener(o -> {
            filter=textFieldSearch.getText();
            currentPage=0;
            initModelSearch();
        });
        tableColumnFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tableColumnLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        tableColumnId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableColumnButtons.setCellFactory( param -> new TableCell<>() {
            private final Button messageBtn = new Button("Message");
            private final Button deleteBtn = new Button("Delete");
            private final Button sendRequestBtn = new Button("Send Request");
            private final HBox buttonBox = new HBox(30); // Layout for buttons
            {
                // Set the "Message" button's action

                messageBtn.setOnAction(event -> {
                    try {
                        handleOpenChat(getTableRow().getItem());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });

                // Set the "Delete" button's action
                deleteBtn.setOnAction(event -> {
                    Utilizator user = getTableRow().getItem();
                    if (user != null) {
                        handleDeleteFriend(user);
                    }
                });
                buttonBox.getChildren().addAll(messageBtn, deleteBtn);
            }

            private final HBox buttonBoxNonFriend = new HBox(30); // Layout for buttons
            {
                // Set the "Message" button's action

                sendRequestBtn.setOnAction(event -> {
                    Utilizator user = getTableRow().getItem();
                    if (user != null) {
                        handleAddFriend(user);
                    }
                });

                buttonBoxNonFriend.getChildren().addAll(sendRequestBtn);
            }

            @Override
            public void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || getTableRow().getItem() == null) {
                    setGraphic(null); // Remove the buttons if the row is empty
                } else {
                    Utilizator currentRowItem = getTableRow().getItem();

                    // Check if the current row item is in the friends list
                    setGraphic(buttonBoxNonFriend);
                    for (Utilizator friend : friends) {
                        if (friend.getId().equals(currentRowItem.getId())) {
                            setGraphic(buttonBox);
                        }
                    }
                }
            }
        });
        tableView.setItems(model);
        initModelFriends();
    }

    private void handleOpenChat(Utilizator user) throws IOException {
        Session s = Session.getInstance();
        Optional<Utilizator> curent = service.findOne(s.getSessionID());

        for (Utilizator friend : service_r.getMyPendingRequests(curent.get())) {
            if (Objects.equals(friend.getId(), user.getId())) {
                MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "This user is not a friend. They haven't accepted your friend request yet.");
                return;
            }
        }

        for (Utilizator friend : service_r.getUsersWithPendingRequests(user)) {
            if (Objects.equals(friend.getId(), curent.get().getId())) {
                MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "This user is not a friend. Consider accepting their friend request.");
                return;
            }
        }

        for (Utilizator friend : service_r.getFriends(curent.get())) {
            if (friend.getId() == user.getId()) {
                openChat(user);
                return;
            }
        }
        MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "This user is not a friend. Consider sending them a friend request.");
    }

    private void openChat(Utilizator user) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(HelloApplication.class.getResource("views/chat-view.fxml"));
        AnchorPane root = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Chat with " + user.getFirstName() + " " + user.getLastName());
        dialogStage.initModality(Modality.WINDOW_MODAL);
        Scene scene = new Scene(root);
        dialogStage.setScene(scene);
        ChatController editUserController = loader.getController();
        editUserController.setService(service_r, service, messagesService, dialogStage,
                service.findOne(Session.getInstance().getSessionID()).get(), user);

        dialogStage.show();
    }

    private void initModelFriends() {
            if(textFieldSearch.getText()!="")
            {
                initModelSearch();
                return;
            }
            Session s=Session.getInstance();
            Optional<Utilizator> utilizator = service.findOne(s.getSessionID());

            if(utilizator.isPresent()) {
                welcomeMessage.setText("Hello, "  + utilizator.get().getFirstName()+"!");
                friends = service_r.getFriends(utilizator.get());
            }
            else{
                friends = service.getAll();
                welcomeMessage.setText("Hey, you should login!");
            }

            Page<Utilizator> pageContent = service_r.findAllOnPage(new Pageable(currentPage, currentPageSize),
                    utilizator.get(), null);
            List<Utilizator> list=StreamSupport.stream(pageContent.elementsOnPage().spliterator(), false).toList();
            model.setAll(list);
            int noOfPages=(int)Math.ceil((double)pageContent.getTotalNumberOfElements()/currentPageSize);
            if(currentPage==0 && currentPage==noOfPages){
                pageLabel.setText("Page: "+ (currentPage) +" / "+noOfPages);
            }
            else{
                pageLabel.setText("Page: "+ (currentPage+1) +" / "+noOfPages);
            }
            if(currentPage==0)
                previousButton.setDisable(true);
            if(currentPage+1>=noOfPages)
                nextButton.setDisable(true);
            if(currentPage>0)
                previousButton.setDisable(false);
            if(currentPage+1<noOfPages)
                nextButton.setDisable(false);
    }

    private void initModelSearch() {
        filter=textFieldSearch.getText();
        if(filter==""){
            initModelFriends();
            return;
        }


        Page<Utilizator> pageContent = service_r.findAllOnPage(new Pageable(currentPage, currentPageSize),
                null, filter);
        List<Utilizator> list=StreamSupport.stream(pageContent.elementsOnPage().spliterator(), false).toList();
        model.setAll(list);
        int noOfPages=(int)Math.ceil((double)pageContent.getTotalNumberOfElements()/currentPageSize);
        if(currentPage==0 && currentPage==noOfPages){
            pageLabel.setText("Page: "+ (currentPage) +" / "+noOfPages);
        }
        else{
            pageLabel.setText("Page: "+ (currentPage+1) +" / "+noOfPages);
        }
        if(currentPage==0)
            previousButton.setDisable(true);
        if(currentPage+1>=noOfPages)
            nextButton.setDisable(true);
        if(currentPage>0)
            previousButton.setDisable(false);
        if(currentPage+1<noOfPages)
            nextButton.setDisable(false);
    }

    @Override
    public void update(UtilizatorEntityChangeEvent utilizatorEntityChangeEvent) {
        friends=service_r.getFriends(service.findOne(Session.getInstance().getSessionID()).get());
        initModelFriends();
    }

    public void handleAddFriend(Utilizator user) {
        if (user != null) {
            Session s = Session.getInstance();
            Optional<Utilizator> curent = service.findOne(s.getSessionID());


            for (Utilizator friend : service_r.getFriends(curent.get())) {
                if (friend.getId() == user.getId()) {
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "Selection Error", "User is already friend.");
                    return;
                }
            }

            for (Utilizator friend : service_r.getUsersWithPendingRequests(curent.get())) {
                if (friend.getId() == user.getId()) {
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "Selection Error", "User has pending request.");
                    return;
                }
            }

            try {
                Optional<FriendRequest> result=service_r.addFriendRequest(curent.get(), user);
                if(result.isPresent()){
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "This user has already sent you a friend request.");
                }
                else{
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "", "Friend request sent.");
                }
            } catch (Exception e) {
                if(e.getMessage()=="Duplicate ID"){
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "You should be your own best friend! :)");
                }
                else{
                    MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", e.getMessage());
                }
        }
        }
        else MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No user selected.");
    }

    public void handleDeleteFriend(Utilizator user) {
        if (user != null) {
            Session s = Session.getInstance();
            Optional<Utilizator> curent = service.findOne(s.getSessionID());
            try{
                Optional<Prietenie> deleted = service_r.deletePrietenie(curent.get(), user);
                if(deleted.isPresent()) {
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"","Friend deleted.");
                }
            }
            catch (Exception e){
                MessageAlert.showMessage(null, Alert.AlertType.WARNING, "", "User is not a friend.");
            }

        }
        else MessageAlert.showMessage(null, Alert.AlertType.WARNING,"Selection Error","No friend selected.");
    }

    public void handleLogOut(ActionEvent actionEvent) throws IOException {
        Session session=Session.getInstance();
        session.setSessionID(null);
        if(stageRequests!=null){
            stageRequests.close();
            stageRequests=null;
        }
    FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("views/app-start.fxml"));
    Parent root = loader.load();
    Stage stage = (Stage) buttonLogOut.getScene().getWindow();
    stage.setScene(new Scene(root));

    AppStartController userController = loader.getController();
        userController.setUtilizatorService(service, service_r, messagesService);
    }

    public void handleReset(ActionEvent actionEvent) {
        initModelFriends();
    }

    public void handleViewRequests(ActionEvent actionEvent) throws IOException {
        if(stageRequests==null || !stageRequests.isShowing()){
            FXMLLoader loader = new FXMLLoader();
        loader.setLocation(HelloApplication.class.getResource("views/friend-requests.fxml"));
        AnchorPane root = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Friend Requests");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        Scene scene = new Scene(root);
        dialogStage.setScene(scene);

        dialogStage.show();
        stageRequests=dialogStage;

        FriendRequestsController editUserController = loader.getController();
        editUserController.setService(service_r, service, dialogStage);
        }

    }

    public void handlePrevious(ActionEvent actionEvent) {
        currentPage--;
        initModelFriends();
    }

    public void handleNext(ActionEvent actionEvent) {
        currentPage++;
        initModelFriends();
    }


}
