package com.example.guiex1.domain;
import java.util.Objects;

public class FriendRequest extends Entity<Tuple<Long, Long>>{
    private final Long source;
    private final Long destination;

    /**
     * Constructs a Friendship object with the given user IDs.
     * The IDs are stored in a way that ensures the smaller ID is always first in the identifier tuple.
     *
     * @param source The ID of the first user.
     * @param destination The ID of the second user.
     */
    public FriendRequest(Long source, Long destination) {
        super.setId(new Tuple<>(source, destination));
        this.source = source;
        this.destination = destination;
    }

    /**
     * Returns the ID of the first user in the friendship.
     *
     * @return The source.
     */
    public Long getsource() {
        return source;
    }

    /**
     * Returns the ID of the second user in the friendship.
     *
     * @return The destination.
     */
    public Long getdestination() {
        return destination;
    }

    /**
     * Compares this Friendship object to another object for equality.
     * Two Friendship objects are considered equal if they represent the same pair of users,
     * regardless of the order of user IDs.
     *
     * @param o The object to compare with this Friendship.
     * @return true if the object is equal to this Friendship; false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FriendRequest that)) return false;
        return (getsource().equals(that.getsource()) &&
                getdestination().equals(that.getdestination())) ||
                (getdestination().equals(that.getsource())
                        && getsource().equals(that.getdestination()));
    }

    /**
     * Returns a hash code value for this Friendship.
     * The hash code is computed based on the user IDs of the friendship.
     *
     * @return A hash code value for this Friendship.
     */
    @Override
    public int hashCode() {
        if(getsource()<getdestination())
                return Objects.hash(getsource(), getdestination());
        else return Objects.hash(getdestination(), getsource());
    }
}
