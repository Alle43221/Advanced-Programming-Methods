package com.example.guiex1.domain.validators;

import com.example.guiex1.domain.FriendRequest;

import java.util.Objects;

/**
 * The PrietenieValidator class is a singleton that validates instances of the Prietenie class.
 * It checks for conditions that ensure a Prietenie is valid before it can be saved in the repository.
 */
public class FriendRequestValidator implements Validator<FriendRequest> {
    private static FriendRequestValidator instance;

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private FriendRequestValidator() {
    }

    /**
     * Provides a global point of access to the singleton instance of PrietenieValidator.
     *
     * @return The single instance of PrietenieValidator.
     */
    public static FriendRequestValidator getInstance() {
        if(instance == null) {
            instance = new FriendRequestValidator();
        }
        return instance;
    }

    /**
     * Validates a Prietenie object to ensure it meets the necessary criteria.
     *
     * @param obj The Prietenie object to validate.
     * @throws ValidationException If the Prietenie is invalid, for example:
     *                             - If both user IDs are the same (indicating a duplicate Prietenie).
     *                             - If either user ID is less than 0.
     */
    @Override
    public void validate(FriendRequest obj) throws ValidationException {
        if(Objects.equals(obj.getsource(), obj.getdestination())) {
            throw new ValidationException("Duplicate ID");
        }
        if(obj.getsource()<0){
            throw new ValidationException("User ID must be greater than 0");
        }
        if(obj.getdestination()<0){
            throw new ValidationException("User ID must be greater than 0");
        }
    }

}
