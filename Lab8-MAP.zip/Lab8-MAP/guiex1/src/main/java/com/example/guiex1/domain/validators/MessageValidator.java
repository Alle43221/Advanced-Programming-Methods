package com.example.guiex1.domain.validators;

import com.example.guiex1.domain.FriendRequest;
import com.example.guiex1.domain.ReplyMessage;

public class MessageValidator implements Validator<ReplyMessage>{

    @Override
    public void validate(ReplyMessage entity) throws ValidationException {
        if(entity.getMessage() == null || entity.getMessage().trim().equals(""))
            throw new ValidationException("Message is empty");

    }
}
