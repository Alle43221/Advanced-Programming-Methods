package com.example.guiex1.domain.validators;

import com.example.guiex1.domain.Prietenie;

import java.util.Objects;

/**
 * The PrietenieValidator class is a singleton that validates instances of the Prietenie class.
 * It checks for conditions that ensure a Prietenie is valid before it can be saved in the repository.
 */
public class PrietenieValidator implements Validator<Prietenie> {
    private static PrietenieValidator instance;

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private PrietenieValidator() {
    }

    /**
     * Provides a global point of access to the singleton instance of PrietenieValidator.
     *
     * @return The single instance of PrietenieValidator.
     */
    public static PrietenieValidator getInstance() {
        if(instance == null) {
            instance = new PrietenieValidator();
        }
        return instance;
    }

    /**
     * Validates a Prietenie object to ensure it meets the necessary criteria.
     *
     * @param obj The Prietenie object to validate.
     * @throws ValidationException If the Prietenie is invalid, for example:
     *                             - If both user IDs are the same (indicating a duplicate Prietenie).
     *                             - If either user ID is less than 0.
     */
    @Override
    public void validate(Prietenie obj) throws ValidationException {
        if(Objects.equals(obj.getUserId2(), obj.getUserId1())) {
            throw new ValidationException("Duplicate ID");
        }
        if(obj.getUserId2()<0){
            throw new ValidationException("User ID must be greater than 0");
        }
        if(obj.getUserId1()<0){
            throw new ValidationException("User ID must be greater than 0");
        }
    }

}
