package com.example.guiex1.repository.dbrepo;

import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Tuple;
import com.example.guiex1.domain.validators.Validator;
import com.example.guiex1.repository.RepoException;
import com.example.guiex1.repository.Repository;
import com.example.guiex1.utils.paging.Pageable;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

/**
 * PrietenieDBRepository is a repository for managing Prietenie entities in a database.
 * This class provides CRUD (Create, Read, Update, Delete) operations for Prietenies.
 */
public class PrietenieDbRepository implements Repository<Tuple<Long, Long>, Prietenie> {
    private final String url;
    private final String username;
    private final String password;
    private final Validator<Prietenie> validator;

    /**
     * Constructs a PrietenieDBRepository with the specified database connection details and validator.
     *
     * @param url the URL for the database connection
     * @param username the username for database authentication
     * @param password the password for database authentication
     * @param validator the validator used to validate Prietenie entities
     */
    public PrietenieDbRepository(String url, String username, String password, Validator<Prietenie> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
    }

    /**
     * Finds a Prietenie by the IDs of two users in the database.
     *
     * @param a a Tuple containing the IDs of the two users in the Prietenie
     * @return an Optional containing the Prietenie if found, or an empty Optional if not found
     */
    @Override
    public Optional<Prietenie> findOne(Tuple<Long, Long> a) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from friendships WHERE id1 = ? and id2 = ?")
        ) {

            statement.setLong(1, a.getLeft());
            statement.setLong(2, a.getRight());

            ResultSet resultSet=statement.executeQuery();
            if (!resultSet.next())
            {
                return Optional.empty();
            }

            resultSet.getLong("id1");
            resultSet.getLong("id2");
            LocalDateTime time =resultSet.getDate("createdate").toLocalDate().atTime(0, 0, 0);
            Prietenie prietenie = new Prietenie(a.getLeft(), a.getRight(), time);
            return Optional.of(prietenie);
        } catch (SQLException e) {
            //System.out.println(e.getMessage());

            throw new RepoException("Could not fetch Prietenie");
        }
    }


    /**
     * Retrieves all Prietenies from the database.
     *
     * @return an Iterable collection of all Prietenies in the database
     */
    @Override
    public Iterable<Prietenie> findAll() {
        Set<Prietenie> Prietenies = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from friendships");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id1 = resultSet.getLong("id1");
                Long id2 = resultSet.getLong("id2");

                LocalDateTime time =resultSet.getDate("createdate").toLocalDate().atTime(0, 0, 0);
                Prietenie prietenie = new Prietenie(id1, id2, time);
                Prietenies.add(prietenie);
            }
            return Prietenies;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
//            throw new RepoException("Could not fetch Prietenies");
        }
        return null;
    }

    /**
     * Saves a Prietenie entity to the database.
     *
     * @param entity the Prietenie entity to save
     * @return an Optional containing the Prietenie if the save was unsuccessful, or an empty Optional if successful
     */
    @Override
    public Optional<Prietenie> save(Prietenie entity) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO friendships (id1, id2, createdate) VALUES (?, ?, ?)")
        ) {
            validator.validate(entity); //throws ValidationError
            statement.setLong(1, entity.getUserId1());
            statement.setLong(2, entity.getUserId2());
            statement.setObject(3, entity.getCreatedAt());
            int rez = statement.executeUpdate();
            if (rez > 0)
                return Optional.empty();
            else
                return Optional.of(entity);
        } catch (SQLException e) {
            throw new RepoException("Could not save Prietenie");
        }
    }

    /**
     * Deletes a Prietenie by the IDs of the two users involved.
     *
     * @param a a Tuple containing the IDs of the two users in the Prietenie
     * @return an Optional containing the deleted Prietenie if successful, or an empty Optional if not found
     */
    @Override
    public Optional<Prietenie> delete(Tuple<Long, Long> a) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement result = connection.prepareStatement("SELECT * FROM friendships WHERE id1 = ? and id2=?");
             PreparedStatement statement = connection.prepareStatement("DELETE FROM friendships WHERE id1 = ? and id2=?")
        ) {
            result.setLong(1, a.getLeft());
            result.setLong(2, a.getRight());
            statement.setLong(1, a.getLeft());
            statement.setLong(2, a.getRight());
            ResultSet resultSet = result.executeQuery();
            resultSet.next();
            resultSet.getLong("id1");
            resultSet.getLong("id2");

            Prietenie prietenie = new Prietenie(a.getLeft(), a.getRight());
            statement.executeUpdate();
            return Optional.of(prietenie);

        } catch (SQLException e) {
//            System.out.println(e.getMessage());
            throw new RepoException("Could not delete Prietenie - non existent Prietenie");
        }
    }

    /**
     * Updates a Prietenie entity in the database.
     *
     * @param entity the Prietenie entity with updated information
     * @return an Optional containing the updated Prietenie if successful, or an empty Optional if not found
     */
    @Override
    public Optional<Prietenie> update(Prietenie entity) {
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("Select * FROM friendships WHERE id1=? AND id2=?")
        ) {
            statement.setLong(1, entity.getUserId1());
            statement.setLong(2, entity.getUserId2());
            int rez=statement.executeUpdate();
            if(rez<1){
                return Optional.empty();
            }
            return Optional.of(entity);

        } catch (SQLException e) {
//            System.out.println(e.getMessage());
            throw new RepoException("Could not update Prietenie - non existent Prietenie");
        }
    }

}
