module ubb.scs.map.sem13map {
    requires javafx.controls;
    requires javafx.fxml;


    opens ubb.scs.map.sem13map to javafx.fxml;
    exports ubb.scs.map.sem13map;
}