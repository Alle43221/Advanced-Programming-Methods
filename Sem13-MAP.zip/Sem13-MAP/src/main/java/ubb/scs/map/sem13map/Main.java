package ubb.scs.map.sem13map;

public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}

