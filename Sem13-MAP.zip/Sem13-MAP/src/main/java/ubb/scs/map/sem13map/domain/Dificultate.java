package ubb.scs.map.sem13map.domain;

public enum Dificultate {
    USOARA, MEDIE, GREA
}
