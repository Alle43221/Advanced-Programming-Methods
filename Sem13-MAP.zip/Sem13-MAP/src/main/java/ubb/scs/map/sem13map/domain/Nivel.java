package ubb.scs.map.sem13map.domain;

public enum Nivel {
    JUNIOR, MEDIUM, SENIOR
}
